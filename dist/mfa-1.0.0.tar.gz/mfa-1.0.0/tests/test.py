import MFA as MFA

MFA.hola("hola")

